<?php

namespace WebMotivacion\Events;

abstract class Event
{
    //
}
